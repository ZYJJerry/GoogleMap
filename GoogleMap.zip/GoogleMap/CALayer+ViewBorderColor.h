//
//  CALayer+ViewBorderColor.h
//  GoogleMap
//
//  Created by Jerry on 2017/6/5.
//  Copyright © 2017年 周玉举. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import <UIKit/UIKit.h>
@interface CALayer (ViewBorderColor)

@property (nonatomic,weak) UIColor * borderColor;
@end
