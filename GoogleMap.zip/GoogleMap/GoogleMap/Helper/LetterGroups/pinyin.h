/*
 *  pinyin.h
 */


char pinyinFirstLetter(unsigned short hanzi);