//
//  BaseModel.h
//  Health
//
//  Created by Jerry on 16/2/25.
//  Copyright © 2016年 周玉举 All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseModel : UIView
-(NSString *)filterHTML:(NSString *)html;
@end
