//
//  CALayer+ButtonBorderColor.h
//  
//
//  Created by Jerry on 16/7/11.
//  Copyright © 2016年 周玉举 All rights reserved.
//
/**
 *  xib中设置button的边框颜色
 */
#import <QuartzCore/QuartzCore.h>

@interface CALayer (ButtonBorderColor)

@end
