//
//  AppointOrUseAlertView.m
//  GoogleMap
//
//  Created by Jerry on 2017/6/6.
//  Copyright © 2017年 周玉举. All rights reserved.
//

#import "AppointOrUseAlertView.h"
#import "HelperDefine.h"
@implementation AppointOrUseAlertView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.frame = frame;
        self.backgroundColor = WhiteColor;
        
    }
    return self;
}




/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
