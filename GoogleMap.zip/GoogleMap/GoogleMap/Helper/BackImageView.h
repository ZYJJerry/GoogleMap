//
//  BackImageView.h
//  FindBike1.1
//
//  Created by Jerry on 16/7/8.
//  Copyright © 2016年 周玉举 All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BackImageView : UIImageView
/** 用户头像 */
@property (nonatomic,strong)UIButton * iconImage;
@end
