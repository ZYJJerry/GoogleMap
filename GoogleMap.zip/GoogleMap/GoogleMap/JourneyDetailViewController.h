//
//  JourneyDetailViewController.h
//  GoogleMap
//
//  Created by Jerry on 2017/6/15.
//  Copyright © 2017年 周玉举. All rights reserved.
//

#import "BaseViewController.h"

@interface JourneyDetailViewController : BaseViewController
@property (nonatomic,strong)NSDictionary * dic;
@end
