//
//  UserTableViewCell.m
//  FindBike1.0
//
//  Created by Jerry on 16/7/7.
//  Copyright © 2016年 zhouyuju. All rights reserved.
//

#import "UserTableViewCell.h"

@implementation UserTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
