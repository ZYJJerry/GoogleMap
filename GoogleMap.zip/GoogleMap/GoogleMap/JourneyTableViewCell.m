//
//  JourneyTableViewCell.m
//  GoogleMap
//
//  Created by Jerry on 2017/6/14.
//  Copyright © 2017年 周玉举. All rights reserved.
//

#import "JourneyTableViewCell.h"

@implementation JourneyTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
