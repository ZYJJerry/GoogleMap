//
//  NickNameViewController.h
//  GoogleMap
//
//  Created by Jerry on 2017/6/16.
//  Copyright © 2017年 周玉举. All rights reserved.
//

#import "BaseViewController.h"

@interface NickNameViewController : BaseViewController

@end
