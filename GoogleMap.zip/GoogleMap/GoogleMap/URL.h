//
//  URL.h
//  GoogleMap
//
//  Created by Jerry on 2017/6/7.
//  Copyright © 2017年 周玉举. All rights reserved.
//

#ifndef URL_h
#define URL_h
//真实环境
#define SERVER_IP(url) [NSString stringWithFormat:@"http://app.yundanche.com.cn:9002/vs/app/%@/link.do", url]
#endif /* URL_h */
